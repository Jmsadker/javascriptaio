const computer = { memory: '16GB', HD: '8TB' };
const laptop = Object.create(computer);
