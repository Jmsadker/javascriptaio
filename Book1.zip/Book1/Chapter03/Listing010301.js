let orderTotal = 39.99;
let itemPurchased = 'JavaScript All-in-One For Dummies';
let customer = 'Joe Q. Developer';

let thankYou = `${customer}, thank you for your order of ${itemPurchased}. Your payment of ${orderTotal} was successful.`;
