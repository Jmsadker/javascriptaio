class Beverage {
  constructor(size, temperature) {
    this.size = size;
    this.temperature = temperature;
  }
}
